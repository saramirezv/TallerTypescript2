import { Course } from './course.js';

export const dataCourses = [
  new Course("Desarrollo de SW en equipo", "Jose Bocanegra", 3),
  new Course("TI en las organizaciones", "Oscar Gonzales Rojas", 3),
  new Course("Italiano 2", "Camilla Serafini", 3),
  new Course("Sistemas Transaccionales", "German Bravo", 3),
  new Course("Calculo Vectorial", "Camilo Sanabria", 3),
  new Course("Quimica", "Jhon Zapata", 3),
  new Course("Laboratorio de Quimica", "Laura Galindo", 0)
]