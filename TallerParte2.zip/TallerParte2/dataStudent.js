import { Student } from './Student.js';
export var dataStudent = [
    new Student(201921903, 1000697632, '19 Años', 'Cra 12 # 34 - 65', 3001234567),
];
